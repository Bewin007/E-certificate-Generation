var data =`
<div class="flex flex-col md:flex-row bg-white   md:bg-transparent rounded-xl gap-10">
<div class="flex justify-center md:justify-end">
    <div class="w-[120px]  h-[120px] bg-white   shadow-lg  rounded-xl p-4 flex justify-center items-center">
        <img src="static/images/icons/Ecell.jpeg" alt="">
    </div>
</div>
<div class=" bg-white  shadow-lg  rounded-xl p-4 hover:bg-gradient-to-r hover:from-red-50 hover:to-sky-50">
    <h1 class="font-bold text-xl">Step-up in Business analysis - Ecell</h1>
    <p>Lorem ipsum dolor sit amet facere nemo enim. Repellendus hic quas facere. Consequatur sint ut quidem saepe! Soluta assumenda nisi rerum quaerat commodi hic aperiam.</p>                        
    <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
        Download
    </button>
    <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
        View
    </button>  
    <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
        Add to Linked-In
    </button> 
</div>
</div>
`;
document.getElementById("certificate_tabs").innerHTML = data;

async function logMovies() {
    const response = await fetch("http://example.com/movies.json");
    const movies = await response.json();
    console.log(movies);
}